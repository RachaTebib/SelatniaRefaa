<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";

try {
  $conn = new PDO("mysql:host=$servername;dbname=anticancer", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  echo "Connected successfully";
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}

if(isset($_POST['formLogin'])){
  if(!empty($_POST['email-username']) AND !empty($_POST['password1'])){
    $username = htmlspecialchars($_POST['email-username']);
    $password1 = $_POST['password1'];
    
    
    $insertmbr = $conn->prepare("SELECT * FROM doctor WHERE email = ? AND password = ?");
    $insertmbr->execute(array($username,$password1));
    $userexist = $insertmbr->rowCount();
    
    if($userexist == 1){
      $userinfo = $insertmbr->fetch();
      $_SESSION['id'] = $userinfo['id'];
      $_SESSION['firstname'] = $userinfo['firstname'];
      $_SESSION['lasttname'] = $userinfo['lasttname'];
      $_SESSION['email'] = $userinfo['email'];      
      header('Location: doct.php?id='.$_SESSION['id']);
    }else{
      $erreur="wrong email or password";
    }

    // $_SESSION['comptecree'] = "Votre compte a ete bien cree";
    // $erreur="Votre compte a ete bien cree";
  }
  else{
    $erreur="All fields must be completed";
  }
 
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>RP Bloggers - Free Login Page Template With HTML and CSS</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
</head>
<body>
<div class="container">
	<div class="form sign-in-container">
	<form id="formAuthentication" class="mb-3" action="doct.php" method="POST">
	<a href="doct.php" class="app-brand-link gap-2">
          
		  <span class="app-brand-text demo text-body fw-bolder"></span>
		</a>
			<h1>Sign In Doctor</h1>
			<div class="social-container">
				<a href="https://rpbloggers.com/"><i class="fab fa-facebook-f"></i></a>
				<a href="https://rpbloggers.com/"><i class="fab fa-google-plus-g"></i></a>
				<a href="https://rpbloggers.com/"><i class="fab fa-linkedin-in"></i></a>
			</div>
			<input type="text" id="email" name="email" placeholder=" Email">
            
                   
                  
			<input
                      type="password"
                      id="password"
                      class="form-control"
                      name="password1"
					  placeholder="Password"
                      placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                      aria-describedby="password"
                    />
					
                    
			
					<button name="formLogin" class="btn btn-primary d-grid w-100" type="submit">Sign in</button>
					<p class="text-center">
                <span>Already have an account?</span>
                <a href="registerdoctor.php">
                  <span>Sign up instead</span>
                </a>
              </p>
		</form>
		<?php
                if(isset($erreur)){
                  echo '<font color="red">'.$erreur.'</font>';
                }
              ?>
			 
	</div>
	<div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-right">
				<img class="card-img rounded-0" src="img/team/2.jpg" alt="">
				
				
			</div>
		</div>
	</div>
</div>
</body>
</html>

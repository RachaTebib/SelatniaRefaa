<?php 

require_once ('connect.php');

  $id = $_GET['id'];
  $DelSql = "DELETE FROM `consultation` WHERE id=$id";

  $res = mysqli_query($con, $DelSql);
  if ($res) {
    header("Location: listconsultation.php");
  }else{
    echo "Failed to delete";
  }

 ?>


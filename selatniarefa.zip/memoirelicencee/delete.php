<?php 

require_once ('connect.php');

  $id = $_GET['id'];
  $DelSql = "DELETE FROM `listpatient` WHERE id=$id";

  $res = mysqli_query($con, $DelSql);
  if ($res) {
    header("Location: listpatient.php");
  }else{
    echo "Failed to delete";
  }

 ?>


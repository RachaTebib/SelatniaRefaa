

<?php 

require_once ('connect.php');

  $id = $_GET['id'];
  $selSql = "SELECT * FROM `consultation` WHERE id=$id";
  $res = mysqli_query($con, $selSql);
  $r = mysqli_fetch_assoc($res);

  if (isset($_POST) & !empty($_POST)) {
    $numvisit = ($_POST['numvisit']);
    $firstname = ($_POST['firstname']);
    $lastname = ($_POST['lastname']);
    $email = ($_POST['email']);
    
    $tem = $_POST['tem'];
    $det= $_POST['det'];
    $patterns = $_POST['patterns'];
    $diagnostic = $_POST['diagnostic'];
    $temperature = $_POST['temperature'];
    $taille = $_POST['taille'];
    $poind = $_POST['poind'];

    $UpdateSql = "UPDATE `consultation` SET numvisit='$numvisit', first_name='$firstname',  last_name='$lastname', email='$email', tem='$tem', det='$det', patterns='$patterns',diagnostic='$diagnostic', temperature='$temperature', taille='$taille', poind='$poind'  WHERE id=$id ";

    $res = mysqli_query($con, $UpdateSql);
    if ($res) {
      header("location: listconsultation.php");
    }else{
      $erreur = "la mise à jour a échoué.";
    }
  }

 ?>


<!DOCTYPE html>
<html>
<head>
  <title>Anti Cancer</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="se.css" >
</head>
<body>
  <?php   
    include 'na.php';
   ?>

  <div class="container">
    <div class="row pt-4">
        <?php if (isset($erreur)) { ?>
        <div class="alert alert-danger" role="alert">
          <?php echo $erreur; ?>
        </div> <?php } ?>

      <form action="" method="POST" class="form-horizontal col-md-6 pt-4">
        <h2>Consultation</h2>
        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">Visit Number</label>
          <div class="col-sm-10">
            <input type="number" name="numvisit" placeholder="numvisit" class="form-control" id="input1"
            value="<?php echo $r['numvisit'] ?>">
          </div>
        </div>

        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">First Name</label>
          <div class="col-sm-10">
            <input type="text" name="firstname" placeholder="firstname" 
            class="form-control" id="input1"
            value="<?php echo $r['first_name'] ?>">
          </div>
        </div>

        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">Last Name</label>
          <div class="col-sm-10">
            <input type="text" name="lastname" placeholder="lastname" class="form-control" id="input1"
            value="<?php echo $r['last_name'] ?>">
          </div>
        </div>

        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">Email</label>
          <div class="col-sm-10">
            <input type="email" name="email" placeholder="e-mail" class="form-control" id="input1"
            value="<?php echo $r['email'] ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">Time</label>
          <div class="col-sm-10">
            <input type="time" name="tem" placeholder="tem" class="form-control" id="input1"
            value="<?php echo $r['tem'] ?>">
          </div>
        </div>

        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">Date</label>
          <div class="col-sm-10">
            <input type="date" name="det" placeholder="det" class="form-control" id="input1"
            value="<?php echo $r['det'] ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">Patterns</label>
          <div class="col-sm-10">
            <input type="text" name="patterns" placeholder="patterns" class="form-control" id="input1"
            value="<?php echo $r['patterns'] ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">Diagnostic</label>
          <div class="col-sm-10">
            <input type="text" name="diagnostic" placeholder="diagnostic" class="form-control" id="input1"
            value="<?php echo $r['diagnostic'] ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">Temperature</label>
          <div class="col-sm-10">
            <input type="number" name="temperature" placeholder="temperature" class="form-control" id="input1"
            value="<?php echo $r['temperature'] ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">Taille</label>
          <div class="col-sm-10">
            <input type="number" name="taille" placeholder="taille" class="form-control" id="input1"
            value="<?php echo $r['taille'] ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="input1" class="col-sm-2 control-label">Poind</label>
          <div class="col-sm-10">
            <input type="number" name="poind" placeholder="poind" class="form-control" id="input1"
            value="<?php echo $r['poind'] ?>">
          </div>
        </div>

        <div class="pt-4">
          <input type="submit" value="submit" class="btn btn-primary m-3">
          
        </div>
      </form>
    </div>
  </div>
  
  
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>


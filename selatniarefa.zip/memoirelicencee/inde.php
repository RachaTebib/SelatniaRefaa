<?php
$servername="localhost";
$username="user";
$password="";
$conn=mysqli_connect("localhost","root","","anticancer") ;
if ($conn->connect_error)
{
    die("connection failed :". $conn->connect_error);
}
echo "connected successfully"
?>

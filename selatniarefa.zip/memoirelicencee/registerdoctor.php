<?php
$servername = "localhost";
$username = "root";
$password = "";

try {
  $conn = new PDO("mysql:host=$servername;dbname=anticancer", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  echo "Connected successfully";
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}

if(isset($_POST['formInscription'])){
  if(!empty($_POST['username']) AND !empty($_POST['name']) AND !empty($_POST['email'])   AND !empty($_POST['password1'])){
    $username = htmlspecialchars($_POST['username']);
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
 
    $password1 = $_POST['password1'];
    
    $insertmbr = $conn->prepare("INSERT INTO doctor (firstname, lastname, email,  password) VALUES (?,?,?,?)");
    $insertmbr->execute(array($username,$name,$email,$password1));
    $_SESSION['comptecree'] = "Votre compte a ete bien cree";
    header('Location: logindoctor.php');
    $erreur="Your account has been successfully created";
  }
  else{
    $erreur="All fields must be completed";
  }
 
}
?>





<!DOCTYPE html>
<html>
<head>
	<title>RP Bloggers - Free Login Page Template With HTML and CSS</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
</head>
<body>
<div class="container">
	<div class="form sign-in-container">
	<form id="formAuthentication" class="mb-3" action="" method="POST">
            <br>
            <br>
            
			<h1>Sign Up Doctor</h1>
			<div class="social-container">
				<a href="https://rpbloggers.com/"><i class="fab fa-facebook-f"></i></a>
				<a href="https://rpbloggers.com/"><i class="fab fa-google-plus-g"></i></a>
				<a href="https://rpbloggers.com/"><i class="fab fa-linkedin-in"></i></a>
			</div>
			
            <input type="text" id="username" name="username" placeholder="First Name">
            <input type="text" id="name" name="name" placeholder="Last Name">
			
           
			<input type="text" id="email" name="email" placeholder=" Email">
            

				
				  <input type="password" id="password" class="form-control" name="password1" placeholder=" password"
					placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
					aria-describedby="password"
				  />
				  
			  
			
				  <button type="submit" name="formInscription" class="btn btn-primary d-grid w-100" >Sign up</button>

				  <p class="text-center">
                <span>Already have an account?</span>
                <a href="logindoctor.php">
                  <span>Sign in instead</span>
                </a>
              </p>
		
			
            </form>
			<?php
		if(isset($erreur)){
		  echo '<font color="red">'.$erreur.'</font>';
		}
	  ?>


		
        
	</div>
    <div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-right">
				<img class="card-img rounded-0" src="img/team/2.jpg" alt="">
				
				
			</div>
		</div>
	</div>
	
</body>
</html>
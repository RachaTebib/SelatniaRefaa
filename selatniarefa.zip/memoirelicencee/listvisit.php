<?php 
  require_once ('connect.php');
  $ReadSql = "SELECT * FROM `visit` ";

  $res = mysqli_query($con, $ReadSql);

 ?>


<!DOCTYPE html>
<html>
<head>
  <title>Anti Cancer</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="sty.css" >
</head>
<body>

  <?php   
    include 'nav.php';
   ?>
  
  <div class="container">
    <div class="row pt-4">
      <h2>List Visit Patient</h2>

      
    </div>

    <table class="table table-striped mt-3">
      <thead>
        <tr>
          <th>id</th>
          <th>Nom complet</th>
          <th>Time</th>
          <th>Date</th>
         
         
        </tr>
      </thead>

      <tbody>
        <?php while ($r = mysqli_fetch_assoc($res)) {
        ?>

        <tr>
          <th scope="row"><?php echo $r['id']; ?></th>
          <td><?php echo $r['first_name'] ." ". $r['last_name']; ?></td>
          <td><?php echo $r['tem']; ?></td>
          <td><?php echo $r['det']; ?></td>
          

        </tr>
      <?php } ?>
      </tbody>
    </table>


  </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>


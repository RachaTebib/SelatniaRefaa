<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> 
        CSS List Item Hover Effects
    </title>
    <link rel="stylesheet" href="doct.css">
    
</head>
<body>
    <div class="container">
        
        <h2>Doctor</h2>
        <ul>
            <li><p>List Visit Patient  <a href="addvisit.php">
                <span>SEE</span>
              </a></p>  </li>
             
              <li><p>Lisit Patient <a href="listpatient.php">
                <span>SEE</span>
              </a></p>  </li>
              
              <li><p>Consultation  <a href="consultation.php">
                <span>SEE</span>
              </a></p>  </li>
              <li><p>Calendar of Doctors   <a href="calendar.php">
                <span>SEE</span>
              </a></p>  </li>
           
           
           
           
         
        </ul>
    
    </div>
    


    
</body>
</html>
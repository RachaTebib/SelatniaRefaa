<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> 
        CSS List Item Hover Effects
    </title>
    <link rel="stylesheet" href="doct.css">
    
</head>
<body>
    <div class="container">
        
        <h2>Patient</h2>
        <ul>
            
             
              <li><p>Register an appointment<a href="addpatient.php">
                <span>SEE</span>
              </a></p>  </li>
              
              <li><p>Lisit Visit <a href="listvisit.php">
                <span>SEE</span>
             
           
           
           
         
        </ul>
    
    </div>
    


    
</body>
</html>